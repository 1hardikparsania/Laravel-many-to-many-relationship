<html>
<head>
   
</head>
<style>
 
 
</style>
<body>
 
<h1> Laravel Many to Many Example </h1>
<h2> User 1 (John) is playing below Roles

<?php if($user->roles->count() > 0): ?>

  <ul>

  <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $records): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li><?php echo e($records->role_name); ?></li>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </ul>

<?php endif; ?>

<h2> Role 3 (Reader) is played by below Users

<?php if($role->users->count() > 0): ?>

  <ul>

  <?php $__currentLoopData = $role->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $records): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li><?php echo e($records->name); ?></li>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </ul>

<?php endif; ?>

</body>
</html><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/laramanytomany/manytomany/resources/views/index.blade.php ENDPATH**/ ?>